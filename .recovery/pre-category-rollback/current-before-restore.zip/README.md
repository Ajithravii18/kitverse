# KITVERSE — MERN Storefront

React + Vite frontend, Express/Node API, and MongoDB via Mongoose. Mobile-first design with circular collections, team/search filtering, price sorting, pagination, product selection, sizes and a locally saved shopping bag. Now includes secure administration, OTP password reset, persistent sessions, and Razorpay payment integration with server-side signature verification.

## Run locally

Requires Node.js 22.20+ and npm.

1. Run `npm install`.
2. Run `npm run dev`.
3. Open http://127.0.0.1:5174. The API runs on port 4000.

Without `.env`, the API serves a clearly labelled demo catalogue.

## Connect MongoDB

Copy `.env.example` to `.env` and set `MONGODB_URI` to your MongoDB replica set URI. **A replica set is required** because the checkout relies on atomic database transactions for safe inventory reservation.
- Run `npm run seed` to insert sample products.
- Run `node scripts/create-admin.mjs <email> <password>` to create an admin account.
- Run `node scripts/migrate-products.mjs` to upgrade old database products with modern `productType` attributes. (Use `--dry-run` to preview).

## Production and checks

`npm run build` builds React into `client/dist`; `npm start` serves it and the API from Express on port 4000. 

`npm test` runs tests covering catalogue responses, filtering, bounding, validation, atomicity and error handling.
`npm run test:browser` runs full-browser interaction checks against the production build, using Playwright.

## Owner Verification Required

Before going live, the owner MUST verify:
- Verified product photos/data for Retro, Collar, Shorts and Track pants
- Real inventory and measurements
- Legal configuration (shipping/returns/privacy/terms)
- Real email provider for OTP sending
- Razorpay live keys/webhook secret
- Business contact details
- Hosting and MongoDB Replica Set configuration
