$css = @"
/* ══════════════════════════════════════════════
   SCROLL REVEAL — base states
══════════════════════════════════════════════ */
.reveal {
  opacity: 0;
  transform: translateY(24px);
  transition:
    opacity 0.55s cubic-bezier(0.2, 0.8, 0.2, 1),
    transform 0.55s cubic-bezier(0.2, 0.8, 0.2, 1);
  transition-delay: calc(var(--i, 0) * 0.07s);
}
.reveal.is-visible {
  opacity: 1;
  transform: translateY(0);
}

/* Section-level reveal (no stagger) */
section.reveal {
  --i: 0;
  transition-duration: 0.65s;
}

/* Card stagger reveal */
.bestseller-card.reveal,
.product.reveal {
  transition-delay: calc(var(--i, 0) * 0.06s);
}

/* Quality grid articles */
.quality-grid article.reveal {
  transition-delay: calc(var(--i, 0) * 0.1s);
}

/* Respect reduced motion */
@media (prefers-reduced-motion: reduce) {
  .reveal {
    opacity: 1 !important;
    transform: none !important;
    transition: none !important;
  }
}

/* ══════════════════════════════════════════════
   PAGE LOAD — initial skeleton for product grid
══════════════════════════════════════════════ */
@keyframes skeletonPulse {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0.5; }
}
.skeleton-product {
  background: #eceee7;
  border-radius: 0;
  animation: skeletonPulse 1.4s ease-in-out infinite;
}
.skeleton-product-img {
  width: 100%;
  aspect-ratio: 4/5;
  background: #e0e3da;
}
.skeleton-product-text {
  padding: 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.skeleton-product-line {
  height: 13px;
  border-radius: 3px;
  background: #d4d7ce;
}

/* ══════════════════════════════════════════════
   CARD HOVER — lift + glow effect
══════════════════════════════════════════════ */
.product {
  transition: transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1);
}
.product:hover {
  transform: translateY(-6px);
}
.product-image {
  transition: box-shadow 0.3s ease;
}
.product:hover .product-image {
  box-shadow: 0 16px 40px rgba(24,26,22,0.14);
}

/* ══════════════════════════════════════════════
   BUTTON PRESS — micro interaction
══════════════════════════════════════════════ */
.primary:active { transform: scale(0.97); }
.bestseller-add-btn:active { transform: scale(0.95); }

/* ══════════════════════════════════════════════
   ANNOUNCEMENT BAR — subtle slide down
══════════════════════════════════════════════ */
@keyframes slideDown {
  from { opacity: 0; transform: translateY(-100%); }
  to   { opacity: 1; transform: translateY(0); }
}
.announcement {
  animation: slideDown 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) both;
}

/* ══════════════════════════════════════════════
   HEADER — fade + slide in
══════════════════════════════════════════════ */
@keyframes headerReveal {
  from { opacity: 0; transform: translateY(-12px); }
  to   { opacity: 1; transform: translateY(0); }
}
.site-header {
  animation: headerReveal 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) 0.1s both;
}

/* ══════════════════════════════════════════════
   QUALITY GRID — slide up from below
══════════════════════════════════════════════ */
.quality-grid article {
  transition: transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1), box-shadow 0.3s ease, border-color 0.3s ease, background 0.3s ease;
}

/* ══════════════════════════════════════════════
   LOADING STATE — full page skeleton
══════════════════════════════════════════════ */
.page-loading-overlay {
  position: fixed;
  inset: 0;
  background: var(--paper);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 24px;
  animation: fadeOutOverlay 0.5s ease 0.8s both;
}
@keyframes fadeOutOverlay {
  to { opacity: 0; pointer-events: none; }
}
.loading-logo {
  font-family: 'Barlow Condensed', 'Arial Narrow', sans-serif;
  font-size: 56px;
  font-weight: 900;
  font-style: italic;
  letter-spacing: -2px;
  color: var(--ink);
  animation: logoPulse 0.9s ease-in-out infinite alternate;
}
@keyframes logoPulse {
  from { opacity: 0.4; }
  to   { opacity: 1; }
}
.loading-bar-wrap {
  width: 120px;
  height: 3px;
  background: #e0e3da;
  overflow: hidden;
}
.loading-bar {
  height: 100%;
  background: var(--lime);
  animation: loadBar 0.8s cubic-bezier(0.4, 0, 0.2, 1) 0s both;
}
@keyframes loadBar {
  from { width: 0; }
  to   { width: 100%; }
}

/* ══════════════════════════════════════════════
   CHIP FILTER — active state transition
══════════════════════════════════════════════ */
.chips button {
  transition: background 0.18s ease, border-color 0.18s ease, color 0.18s ease, transform 0.15s ease;
}
.chips button:active { transform: scale(0.95); }

/* ══════════════════════════════════════════════
   TOAST — slide up from bottom
══════════════════════════════════════════════ */
@keyframes toastIn {
  from { opacity: 0; transform: translateX(-50%) translateY(20px); }
  to   { opacity: 1; transform: translateX(-50%) translateY(0); }
}
#toast[style*='block'] {
  animation: toastIn 0.3s cubic-bezier(0.2, 0.8, 0.2, 1) both;
}

/* ══════════════════════════════════════════════
   TEAM CAROUSEL ITEMS — hover lift already exists
   add smooth scale on active
══════════════════════════════════════════════ */
.team-item:active .team-circle-stage {
  transform: scale(0.94);
}

/* ══════════════════════════════════════════════
   SECTION DIVIDER — animated gradient line
══════════════════════════════════════════════ */
.ticker {
  position: relative;
}
"@
Add-Content -Path "c:\Users\AJITH\OneDrive\Documents\New project\client\src\style.css" -Value $css
